/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 19:41:09 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/26 19:41:10 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

int			key_off(int key, t_graf *graf)
{
	graf->push[key] = 0;
	return (0);
}

int			key_on(int key, t_graf *graf)
{
	graf->push[key] = 1;
	return (0);
}

int			main_loop(t_graf *graf)
{
	push(graf);
	ft_trace_sky(graf);
	calcul_image(graf);
	mlx_put_image_to_window(graf->mlx, graf->win, graf->img, 0, 0);
	ft_bzero(graf->img->buff, graf->img->width * graf->img->height * 4);
	return (0);
}

void		push(t_graf *graf)
{
	ft_move(graf);
	ft_lateral_move(graf);
	ft_rotate(graf);
	if (graf->push[ESC])
		exit(0);
}
