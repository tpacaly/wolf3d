/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 19:41:15 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/29 15:23:32 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

static void	init_2(t_graf *graf)
{
	graf->dirx = 1;
	graf->diry = 0;
	graf->planex = 0;
	graf->planey = 0.66;
}

static int	**ft_fill_map(void)
{
	int	**map;
	int	i;
	int	j;

	i = -1;
	if (!(map = (int **)malloc(sizeof(int *) * 11)))
		exit(0);
	while (++i < 11)
		if (!(map[i] = (int *)malloc(sizeof(int) * 11)))
			exit(0);
	i = -1;
	while (++i < 11)
	{
		map[0][i] = 1;
		map[10][i] = 1;
	}
	i = 0;
	while (++i < 10)
	{
		j = -1;
		while (++j <= 10)
			map[i][j] = (j == 0 || j == 10) ? 1 : 0;
	}
	map[5][5] = 1;
	return (map);
}

static void	init(t_graf *graf)
{
	int i;

	i = -1;
	graf->nb_l = 11;
	graf->size = 11;
	graf->map = ft_fill_map();
	graf->pos_x = 3.0;
	graf->pos_y = 3.0;
	if (!(graf->push = (int *)malloc(sizeof(int) * 400)))
		exit(0);
	while (++i < 400)
		graf->push[i] = 0;
	init_2(graf);
}

static int	ft_red_cross(void)
{
	exit(0);
	return (0);
}

int			main(int c, char **v)
{
	t_graf	*graf;

	(void)v;
	if ((!(graf = (t_graf*)malloc(sizeof(t_graf)))) || c != 1)
		exit(1);
	if (!(graf->mlx = mlx_init()))
		exit(1);
	graf->win = mlx_new_window(graf->mlx, MAX_X, MAX_Y, "Wolf3d - tpacaly");
	graf->img = (t_image *)mlx_new_image(graf->mlx, MAX_X, MAX_Y);
	init(graf);
	mlx_hook(graf->win, 2, 1, key_on, graf);
	mlx_hook(graf->win, 17, 0, ft_red_cross, 0);
	mlx_key_hook(graf->win, key_off, graf);
	mlx_loop_hook(graf->mlx, main_loop, graf);
	mlx_loop(graf->mlx);
	exit(0);
}
