/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 19:41:15 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/30 14:49:01 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

static void	init_2(t_graf *graf)
{
	graf->dirx = 1;
	graf->diry = 0;
	graf->planex = 0;
	graf->planey = 0.66;
}

static int	**ft_fill_map(int a, int b)
{
	int	**map;
	int	i;
	int	j;

	i = -1;
	if (!(map = (int **)malloc(sizeof(int *) * a)))
		exit(0);
	while (++i < a)
		if (!(map[i] = (int *)malloc(sizeof(int) * b)))
			exit(0);
	i = -1;
	while (++i < b)
	{
		map[0][i] = 1;
		map[a - 1][i] = 1;
	}
	i = 0;
	while (++i < a - 1)
	{
		j = -1;
		while (++j <= b - 1)
			map[i][j] = (j == 0 || j == b - 1) ? 1 : 0;
	}
	map = ft_stock(a, b, map);
	return (ft_verify_map(a, b, map));
}

static void	init(t_graf *graf, int a, int b)
{
	int i;

	i = -1;
	graf->nb_l = a;
	graf->size = b;
	graf->map = ft_fill_map(a, b);
	graf->pos_x = b / 2;
	graf->pos_y = a / 2;
	ft_printf("Map : x = %d y = %d ; posx = %f posy = %f\n",
			b, a, graf->pos_x, graf->pos_y);
	if (!(graf->push = (int *)malloc(sizeof(int) * 400)))
		exit(0);
	while (++i < 400)
		graf->push[i] = 0;
	init_2(graf);
}

static int	ft_red_cross(void)
{
	exit(0);
	return (0);
}

int			main(int c, char **v)
{
	t_graf	*graf;
	int		a;
	int		b;

	if (c != 3)
		exit(1 + (0 + ft_printf("3 arguments, not %d.\n", c)));
	a = ft_atoi(v[2]);
	b = ft_atoi(v[1]);
	if ((!(graf = (t_graf*)malloc(sizeof(t_graf)))))
		exit(1 + (0 + ft_printf("failed malloc.")));
	if (((graf->mlx = mlx_init()) == NULL) || a < 8 || a > 1024 || b < 8
		|| b > 1024)
		exit(1 + (0 + ft_printf("1024 < X < 8 || 1024 < Y < 8 x=%d y=%d\n"
			, a, b)));
	graf->win = mlx_new_window(graf->mlx, MAX_X, MAX_Y, "Wolf3d");
	graf->img = (t_image *)mlx_new_image(graf->mlx, MAX_X, MAX_Y);
	init(graf, a, b);
	mlx_hook(graf->win, 2, 1, key_on, graf);
	mlx_hook(graf->win, 17, 0, ft_red_cross, 0);
	mlx_key_hook(graf->win, key_off, graf);
	mlx_loop_hook(graf->mlx, main_loop, graf);
	mlx_loop(graf->mlx);
	exit(0);
}
