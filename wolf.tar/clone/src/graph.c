/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   graph.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 19:41:04 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/30 11:52:19 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

void	put_pixel_to_img(unsigned int color, int x, int y, t_graf *graf)
{
	if (x < graf->img->width && y < graf->img->height && x >= 0 && y >= 0)
		((unsigned int *)(graf->img->buff))[x + y *
			graf->img->width] = color;
}

void	ft_basic_wall(int map_x, int map_y, t_graf *graf)
{
	int pos_x;
	int pos_y;

	pos_y = (int)(graf->pos_y);
	pos_x = (int)(graf->pos_x);
	if (map_x >= pos_x && graf->vertical0 == 0)
		graf->color = 0x523e27;
	else if (map_x <= pos_x && graf->vertical0 == 0)
		graf->color = 0xdec56a;
	else if (map_y >= pos_y && graf->vertical0 == 1)
		graf->color = 0x527b54;
	else if (map_y <= pos_y && graf->vertical0 == 1)
		graf->color = 0xd5c2c2;
}

void	draw_wall(int x, int draw_start, int draw_end, t_graf *graf)
{
	while (draw_start <= draw_end)
	{
		put_pixel_to_img(graf->color, x, draw_start, graf);
		draw_start++;
	}
}

void	ft_trace_sky(t_graf *graf)
{
	int y;
	int x;

	y = 0;
	while (y <= MAX_Y / 2)
	{
		x = -1;
		while (++x <= MAX_X)
			put_pixel_to_img(0xBFE4E5, x, y, graf);
		y++;
	}
	while (y <= MAX_Y)
	{
		x = -1;
		while (++x <= MAX_X)
			put_pixel_to_img(0x3e1b45, x, y, graf);
		y++;
	}
}
