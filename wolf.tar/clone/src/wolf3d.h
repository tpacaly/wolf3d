/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf3d.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 11:55:30 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/30 13:18:23 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WOLF3D_H
# define WOLF3D_H
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <math.h>
# include <fcntl.h>
# include "key_define.h"
# include "../libft/sources/ft_printf.h"
# include "../minilibx_macos/mlx.h"
# define MAX_X 1280
# define MAX_Y 720

typedef struct		s_image
{
	int				width;
	int				height;
	char			*buff;
}					t_image;

typedef struct		s_file
{
	char			*name;
	int				fd;
	short			x;
	short			y;
	int				tailllig;
}					t_file;

typedef struct		s_graf
{
	t_file			file;
	int				**map;
	int				map_value;
	void			*mlx;
	void			*win;
	t_image			*img;
	int				*push;
	unsigned int	color;
	float			pos_x;
	float			pos_y;
	float			move_speed;
	float			rot_speed;
	int				map_x;
	int				map_y;
	int				inc_x;
	int				inc_y;
	double			inc_x2;
	double			inc_y2;
	double			dist_v;
	double			dist_h;
	float			dirx;
	float			diry;
	double			planex;
	double			planey;
	double			raypos_x;
	double			raypos_y;
	double			r_dir_x;
	double			r_dir_y;
	double			wall_d;
	int				vertical0;
	int				size;
	int				nb_l;
}					t_graf;

void				ft_stock(int a, int b, int **map);
void				put_pixel_to_img(unsigned int color,
						int x, int y, t_graf *graf);
int					key_off(int key, t_graf *graf);
int					key_on(int key, t_graf *graf);
int					main_loop(t_graf *graf);
void				push(t_graf *graf);
void				ft_map(const int fd, t_graf *graf);
void				ft_rotate(t_graf *graf);
void				ft_lateral_move(t_graf *graf);
void				ft_move(t_graf *graf);
void				use(void);
int					main(int ac, char **av);
void				calcul_image(t_graf *graf);
void				ft_trace_sky();
void				draw_wall(int x, int draw_start,
						int draw_end, t_graf *graf);
void				ft_basic_wall(int map_x, int map_y, t_graf *graf);
void				ft_spawn(t_graf *graf);
void				ft_map_check(t_graf *graf);

#endif
