/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 19:41:19 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/30 14:54:09 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

static	void	rotate_left(t_graf *graf)
{
	double old_dx;
	double old_planx;

	old_dx = graf->dirx;
	old_planx = graf->planex;
	graf->dirx = graf->dirx * cos(-graf->rot_speed) -
		graf->diry * sin(-graf->rot_speed);
	graf->diry = old_dx * sin(-graf->rot_speed) +
		graf->diry * cos(-graf->rot_speed);
	graf->planex = graf->planex * cos(-graf->rot_speed) -
		graf->planey * sin(-graf->rot_speed);
	graf->planey = old_planx * sin(-graf->rot_speed) +
		graf->planey * cos(-graf->rot_speed);
}

void			ft_rotate(t_graf *graf)
{
	double old_dx;
	double old_planx;

	if (graf->push[A] != 0)
		rotate_left(graf);
	if (graf->push[D] != 0)
	{
		old_dx = graf->dirx;
		old_planx = graf->planex;
		graf->dirx = graf->dirx * cos(graf->rot_speed) -
			graf->diry * sin(graf->rot_speed);
		graf->diry = old_dx * sin(graf->rot_speed) +
			graf->diry * cos(graf->rot_speed);
		old_planx = graf->planex;
		graf->planex = graf->planex * cos(graf->rot_speed) -
			graf->planey * sin(graf->rot_speed);
		graf->planey = old_planx * sin(graf->rot_speed) +
			graf->planey * cos(graf->rot_speed);
	}
}

void			ft_lateral_move(t_graf *graf)
{
	double	tmp_diry;

	if (graf->push[LT] != 0)
	{
		tmp_diry = graf->dirx * sin(-90) + graf->diry * cos(-90);
		if (graf->map[(int)(graf->pos_y + tmp_diry * graf->move_speed)]
				[(int)(graf->pos_x)] == 0)
			graf->pos_y += tmp_diry * graf->move_speed;
	}
	if (graf->push[RT] != 0)
	{
		tmp_diry = graf->dirx * sin(90) + graf->diry * cos(90);
		if (graf->map[(int)(graf->pos_y + tmp_diry * graf->move_speed)]
				[(int)(graf->pos_x)] == 0)
			graf->pos_y += tmp_diry * graf->move_speed;
	}
}

void			ft_move(t_graf *graf)
{
	graf->move_speed = 0.04;
	graf->rot_speed = 0.02;
	if (graf->push[UP] != 0)
	{
		if (graf->map[(int)(graf->pos_y)]
				[(int)(graf->pos_x + graf->dirx * graf->move_speed)] == 0)
			graf->pos_x += (double)(graf->dirx * graf->move_speed);
		if (graf->map[(int)(graf->pos_y + graf->diry * graf->move_speed)]
				[(int)(graf->pos_x)] == 0)
			graf->pos_y += graf->diry * graf->move_speed;
	}
	if (graf->push[DN] != 0)
	{
		if (graf->map[(int)(graf->pos_y)]
				[(int)(graf->pos_x - graf->dirx * graf->move_speed)] == 0)
			graf->pos_x -= graf->dirx * graf->move_speed;
		if (graf->map[(int)(graf->pos_y - graf->diry * graf->move_speed)]
				[(int)(graf->pos_x)] == 0)
			graf->pos_y -= graf->diry * graf->move_speed;
	}
}
