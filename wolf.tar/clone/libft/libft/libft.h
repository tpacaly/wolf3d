/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/16 22:23:16 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/29 15:17:56 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# define LBITS 0x101010101010101L
# define HBITS 0x8080808080808080L
# define BUFF_SIZE 8
# define MAX_FD 2048
# include <limits.h>
# include <fcntl.h>
# include <unistd.h>
# include <string.h>
# include <stdlib.h>

unsigned long long		ft_atoi(char *str);
void					ft_bzero(void *s, size_t n);

void					*ft_memchr(const void *mem, const unsigned char c,
		size_t n);
void					*ft_memcpy(void *dest, const void *src, size_t n);
void					*ft_memset(void *s, int c, size_t n);

double					ft_pow(double n, int pow);

char					*ft_strchr(const char *s, int c);
int						ft_strchri(char *s, int c, int i);
int						ft_strchri_lu(char *s, int c, int i);

size_t					ft_strlen(const char *str);

int						ft_strncmp(const char *s1, const char *s2, size_t n);

size_t					ft_wcharlen(unsigned c);
size_t					ft_wstrlen(unsigned *s);

void					ft_strdel(char **as);
void					ft_memdel(void **ap);
char					*ft_strdup(const char *s1);
char					**ft_strsplit(char const *s, char c);
char					*ft_itoa(int n);
void					*ft_memalloc(size_t size);
char					*ft_strjoin(char const *s1, char const *s2);
int						get_next_line(const int fd, char **line);
char					*ft_strjoin(char const *s1, char const *s2);
char					**ft_strsplit(char const *s, char c);
char					*ft_strcpy(char *dst, const char *src);
char					*ft_strcat(char *s1, const char *s2);
char					*ft_strsub(char const *s, unsigned int start,
		size_t len);
void					*ft_memmove(void *dst, const void *src, size_t len);

#endif
