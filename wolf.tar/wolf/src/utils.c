/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/30 13:57:45 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/30 19:26:04 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

int				**ft_stock(int a, int b, int **map)
{
	int i;
	int t;

	i = 2;
	t = 2;
	while (i < a - 1)
	{
		while (t < b - 1)
		{
			map[i][t] = 1;
			t += 2;
		}
		t = 0;
		i += 2;
	}
	return (map);
}

int				**ft_verify_map(int a, int b, int **map)
{
	int i;
	int j;

	i = -1;
	while (++i < b)
	{
		map[0][i] = 1;
		map[a - 1][i] = 1;
	}
	i = 0;
	while (++i < a - 1)
	{
		j = -1;
		while (++j <= b - 1)
			map[i][j] = (j == 0 || j == b - 1) ? 1 : map[i][j];
	}
	return (map);
}
