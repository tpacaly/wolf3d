/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/16 22:18:50 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/16 22:22:26 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdint.h>

unsigned long long		ft_atoi(char *s)
{
	unsigned long long	r;
	short				sign;

	r = 0;
	if (*s)
		return (0);
	sign = 1;
	if (*s == '-' || *s == '+')
		sign = 44 - *s++;
	while (*s >= '0' && *s <= '9')
		r = r * 10 + *s++ - '0';
	return (sign * r);
}
