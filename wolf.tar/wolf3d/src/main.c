/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 19:41:15 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/29 15:23:32 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

static void	init_2(t_graf *graf)
{
	graf->dirx = 1;
	graf->diry = 0;
	graf->planex = 0;
	graf->planey = 0.66;
}

static int	**ft_fill_map(int a, int b)
{
	int	**map;
	int	i;
	int	j;

	i = -1;
	if (!(map = (int **)malloc(sizeof(int *) * a)))
		exit(0);
	while (++i < a)
		if (!(map[i] = (int *)malloc(sizeof(int) * b)))
			exit(0);
	i = -1;
	while (++i < b)
	{
		map[0][i] = 1;
		map[a-1][i] = 1;
	}
	i = 0;
	while (++i < a-1)
	{
		j = -1;
		while (++j <= b-1)
			map[i][j] = (j == 0 || j == b-1) ? 1 : 0;
	}
	map[a/2][b/2] = 1;
	return (map);
}

static void	init(t_graf *graf, int a, int b)
{
	int i;

	i = -1;
	graf->nb_l = a;
	graf->size = b;
	graf->map = ft_fill_map(a, b);
	graf->pos_x = 3.0;
	graf->pos_y = 3.0;
	if (!(graf->push = (int *)malloc(sizeof(int) * 400)))
		exit(0);
	while (++i < 400)
		graf->push[i] = 0;
	init_2(graf);
}

static int	ft_red_cross(void)
{
	exit(0);
	return (0);
}

int			main(int c, char **v)
{
	t_graf	*graf;
	int a;
	int b;

	if (c != 3)
		exit(1);
	a = ft_atoi(v[1]);
	b = ft_atoi(v[2]);
	if ((!(graf = (t_graf*)malloc(sizeof(t_graf)))))
		exit(1);
	if ((!(graf->mlx = mlx_init())) || a < 8 || a > 4096 || b < 8 || b >
		4096)
		exit(1);
	graf->win = mlx_new_window(graf->mlx, MAX_X, MAX_Y, "Wolf3d");
	graf->img = (t_image *)mlx_new_image(graf->mlx, MAX_X, MAX_Y);
	init(graf, a, b);
	mlx_hook(graf->win, 2, 1, key_on, graf);
	mlx_hook(graf->win, 17, 0, ft_red_cross, 0);
	mlx_key_hook(graf->win, key_off, graf);
	mlx_loop_hook(graf->mlx, main_loop, graf);
	mlx_loop(graf->mlx);
	exit(0);
}
